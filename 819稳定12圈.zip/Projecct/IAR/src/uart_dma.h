#include "car_global.h"

void UART_DMA_Init(void);
void DMA_start();
